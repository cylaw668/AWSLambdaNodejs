exports.handler = async (event) => {
    let item = {
        description:'A pair of shoe',
        colour: 'red',
        size: '40',
        price: '$45.5'
    };
    const response = {
        statusCode: 200,
        body: JSON.stringify(item),
    };
    return response;
};
